local mysql = require "resty.mysql"
--host = "10.0.2.15",ok
--host = "172.17.0.1",ok
--host = "192.168.49.1",ok
--host = "192.168.56.106",ok
--host = "172.18.0.1",ok
local config = {
    host = "svcmysql.default.svc.cluster.local",
    port = 3306,
    database = "app",
    user = "root",
    password = "123456",
    charset = "utf8mb4",
}

local _M={}

function _M.new(self)
    local db, err = mysql:new()
    if not db then
        return nil
    end
    db:set_timeout(1000) -- 1 sec

    local ok, err, errno, sqlstate = db:connect(config)

    if not ok then
        return nil
    end
    db.close = close
    return db
end

function close(self)
	local sock = self.sock
    if not sock then
        return nil, "not initialized"
    end
    if self.subscribed then
        return nil, "subscribed state"
    end
    return sock:setkeepalive(10000, 50)
end

return _M
