local json = require "cjson"
local mysql = require "lua.mysql"
--local resty_uuid = require"resty.uuid"
-- 创建MySQL连接池
local function create_mysql_connection()
    local db = mysql:new()
    return db
end
-- 生成唯一用户ID
--local function generate_user_id()
    --local uuid = resty_uuid.generate()
    --return string.sub(uuid, 1, 8)  -- 只使用UUID的前8位作为用户ID
--end
-- 注册处理函数
local function signup_handler()

    ngx.req.read_body()
    local arg = ngx.req.get_post_args()
-- 参数校验
    local username = arg.username
    local password = arg.password
    local repassword = arg.repassword

    if not (username and password and repassword) then
        ngx.status = ngx.HTTP_BAD_REQUEST
        ngx.say(json.encode({code = 1, msg = "Invalid parameters"}))
        return
    end

    if password ~= repassword then
        ngx.status = ngx.HTTP_BAD_REQUEST
        ngx.say(json.encode({code = 1, msg = "Passwords do not match"}))
        return
    end
    
 -- 查询数据库判断用户是否存在
    local db = create_mysql_connection()
    if not db then
        ngx.status = ngx.HTTP_INTERNAL_SERVER_ERROR
        ngx.say(json.encode({ code = 1, msg = "Failed to connect to the database" }))
        ngx.log(ngx.ERR, "Failed to connect to the database: ", err)
        return
    end
--不写select * 写count（*）一直报#res查询数为0
    local sqlstr = [[select * from user where username = "]] ..ngx.quote_sql_str(username)..[["]]
    local res, err = db:query(sqlstr)
    if not res then
        ngx.status = ngx.HTTP_INTERNAL_SERVER_ERROR
        ngx.say(json.encode({code = 1, msg = "failed to execute query"}))
        ngx.log(ngx.ERR,"failed to execute query")
        return
    end
    
    if #res > 0 then
        ngx.say(json.encode({code = 1, msg = "user already exist"}))
        return
    end
-- 生成用户ID
--local new_user_id = generate_user_id()
    local userid = ngx.now()
-- 将用户信息保存到数据库ngx.quote_sql_str(username)
    sql = [[insert into user (user_id, username, password) values ( ]]..ngx.quote_sql_str(userid).. "," ..ngx.quote_sql_str(username)..","..ngx.quote_sql_str(password)..")"
    ngx.say(json.encode({code = 1, msg = sql}))
    
    local res, err = db:query(sql)
    if not res then
        ngx.status = ngx.HTTP_INTERNAL_SERVER_ERROR
        ngx.say(json.encode({code = 1, msg = "failed to save user"}))
        ngx.log(ngx.ERR,"failed to save user")
        return
    end
-- 记录日志
    ngx.log(ngx.INFO,"User registered:",username)
    ngx.say(json.encode({code = 2, msg = "user resistered successfully"}))

    db:close()
end

ngx.req.read_body()
local uri_args = ngx.req.get_uri_args()

if ngx.req.get_method() == "POST" and uri_args and uri_args.action == "signup" then
    signup_handler()
else
    ngx.status = ngx.HTTP_NOT_FOUND
    ngx.say("page not found")
end
