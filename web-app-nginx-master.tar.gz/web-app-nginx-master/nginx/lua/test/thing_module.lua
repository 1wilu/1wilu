local _M = {}

function _M.greet()
    print("HI!!!")
end

return _M
