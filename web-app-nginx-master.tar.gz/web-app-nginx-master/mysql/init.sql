CREATE DATABASE app;
USE app;
CREATE TABLE user (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    user_id BIGINT(20) NOT NULL,
    username varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
    password varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
    email varchar(64) COLLATE utf8mb4_general_ci,
    PRIMARY KEY (id)
);
